package com.company;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

    private static long paymentSum = 0;

    //The following variables can be changed based on the user's needs
    private static int rowCount = 2;
    private static long depDepositAmount = 100000;

    public static void main(String[] args) {

        try {
            //create salary payment folder
            Path SalaryPaymentPath = Paths.get("C:\\SalaryPayment");
            Path SalaryPaymentDirectory = Files.createDirectories(SalaryPaymentPath);

            List<Path> paths = createFiles(rowCount);

            String endMessage= salaryPayment(paths.get(0), paths.get(1), paths.get(2));
            System.out.println(endMessage);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * this method for create payment file and inventor file
     * @return return is true if created file
     * @param rowCount is file row count
     * @return return lists of path
     */
    private static List<Path> createFiles(int rowCount) throws IOException {

        //create payment and inventory file
        Path paymentPath = Paths.get("C:\\SalaryPayment\\payment.txt");
        Path inventoryPath = Paths.get("C:\\SalaryPayment\\inventory.txt");
        Path transactionPath = Paths.get("C:\\SalaryPayment\\transaction.txt");

        List<Path> pathsList = new ArrayList<Path>();
        pathsList.add(paymentPath);
        pathsList.add(inventoryPath);
        pathsList.add(transactionPath);

        //create payment file
        try(BufferedWriter paymentWriter = Files.newBufferedWriter(paymentPath)){

            for(int i=0; i<rowCount; i++){

                int randomNum = ThreadLocalRandom.current().nextInt(100, 1000 + 1);
                paymentSum += randomNum;
                StringBuilder paymentRow = new StringBuilder();
                paymentRow.append("creditor"+ " " + "1.20.100." + i + " " + randomNum + System.lineSeparator());
                paymentWriter.write(paymentRow.toString());
            }
            paymentWriter.write("deptor" + " " + "1.10.100.1" + " " + depDepositAmount);

        } catch (Exception e){
            e.printStackTrace();
        }

        //create inventor file
        if(!Files.exists(inventoryPath) || Files.lines(inventoryPath).count() == 0){

            try(BufferedWriter inventorWriter = Files.newBufferedWriter(inventoryPath)){
                for(int i=0; i<rowCount; i++) {
                    StringBuilder inventorRow = new StringBuilder();
                    inventorRow.append("1.20.100." + i + " " + 0 + System.lineSeparator());
                    inventorWriter.write(inventorRow.toString());
                }
                inventorWriter.append("1.10.100.1" + " " + depDepositAmount);
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return pathsList;
    }
    /**
     * this method for process payment file,inventor file and register log on the transaction file
     * @return return is a text for process finished
     * @param paymentPath is for payment file
     * @param inventoryPath is for inventory file
     * @param transactionPath is for transaction file
     * @return text message for process is finished
     */
    private static String salaryPayment(Path paymentPath,  Path inventoryPath, Path transactionPath){

        if(depDepositAmount > paymentSum) {
            try {
                Stream<String> paymentStream = Files.lines(paymentPath);
                Stream<String> paymentStreamForList = Files.lines(paymentPath);
                Stream<String> inventoryStream = Files.lines(inventoryPath);

                StringBuilder debtorNewPayment = new StringBuilder();
                StringBuilder transaction = new StringBuilder();

                //found debtor in payment file
                String debtor = paymentStream.filter(s -> s.startsWith("d")).collect(Collectors.joining());
                List<String> debtorDetails = Arrays.asList(debtor.split(" "));
                long debtorDipositAmount = Long.parseLong(debtorDetails.get(2));
                String debtorDipositNumber = debtorDetails.get(1);

                //convert payment and inventor file to list
                List<String> inventoryList = inventoryStream.collect(Collectors.toList());
                List<String> paymentList = paymentStreamForList.collect(Collectors.toList());
                List<String> newInventoryList = new ArrayList<String>();
                List<String> newPaymentList = new ArrayList<String>();


                for (String payment : paymentList) {

                    boolean hasPaymentInInventory = true;
                    List<String> spelitedPayment = Arrays.asList(payment.split(" "));
                    String paymentDepositNumber = spelitedPayment.get(1);
                    long paymentDepositAmount = Long.valueOf(spelitedPayment.get(2));

                    for (String inventory : inventoryList) {

                        if (inventory.equals("")) {
                            continue;
                        }
                        List<String> spelitedInventory = new ArrayList<String>();
                        String[] spelitedInventoryArray = inventory.split(" ");
                        for (String s : spelitedInventoryArray) {
                            spelitedInventory.add(s);
                        }
                        String inventoryDepositNumber = spelitedInventory.get(0);
                        long inventoryDepositAmount = Long.valueOf(spelitedInventory.get(1));
                        StringBuilder newInventory = new StringBuilder();

                        if (inventoryDepositNumber.equals(paymentDepositNumber) && !inventoryDepositNumber.equals(debtorDipositNumber)) {
                            hasPaymentInInventory = false;
                            String newAmount = String.valueOf(inventoryDepositAmount + paymentDepositAmount);
                            spelitedInventory.set(1, newAmount);

                            for (String newInv : spelitedInventory) {
                                newInventory.append(newInv + " ");
                            }
                            newInventoryList.add(newInventory.toString());

                            //update debtor deposit amount
                            debtorDipositAmount = debtorDipositAmount - paymentDepositAmount;

                            transaction.append(debtorDipositNumber + " " + inventoryDepositNumber + " " + paymentDepositAmount + System.lineSeparator());

                        } else{
                            continue;
                        }
                    }
                    if(hasPaymentInInventory && !paymentDepositNumber.equals(debtorDipositNumber)){
                        newPaymentList.add(payment);
                        transaction.append(debtorDipositNumber + " " + paymentDepositNumber + " " + paymentDepositAmount + System.lineSeparator());
                        debtorDipositAmount = debtorDipositAmount - paymentDepositAmount;
                    }
                }

                //write to transaction file
                if (!Files.exists(transactionPath))
                    Files.createFile(transactionPath);
                Files.write(transactionPath, transaction.toString().getBytes(), StandardOpenOption.APPEND);

                //write new value in inventor file
                debtorNewPayment.append(debtorDipositNumber + " " + debtorDipositAmount + System.lineSeparator());
                Files.write(inventoryPath, debtorNewPayment.toString().getBytes());
                for (String ni : newInventoryList) {
                    Files.write(inventoryPath, System.lineSeparator().getBytes(), StandardOpenOption.APPEND);
                    Files.write(inventoryPath, ni.getBytes(), StandardOpenOption.APPEND);
                }

                //new payments where does not exist in inventory file
                for (String np : newPaymentList){
                    Files.write(inventoryPath, System.lineSeparator().getBytes(), StandardOpenOption.APPEND);
                    Files.write(inventoryPath, np.substring(9).getBytes(), StandardOpenOption.APPEND);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return "*********************** THE PROCESS IS COMPLETE **********************";

        } else {
            String message = "INVENTORY IS NOT ENOUGH" + " " + "(deptorDepositAmount: " + depDepositAmount + " " + "paymentSum: " + paymentSum+")";
            return message;
        }
    }
}
